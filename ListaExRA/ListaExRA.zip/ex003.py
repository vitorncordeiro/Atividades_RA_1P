"""Faça um Programa que leia 4 notas, mostre as notas e a média na tela."""
notas = [5, 7, 9, 9.5]
media = sum(notas) / len(notas)
print(f'Notas: {notas} | Média Final: {media}')