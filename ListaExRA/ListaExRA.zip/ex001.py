"""Faça um Programa que leia um vetor de 5 números inteiros e mostre-os."""
lista = [1, 2, 3, 4, 5]
print(*lista)